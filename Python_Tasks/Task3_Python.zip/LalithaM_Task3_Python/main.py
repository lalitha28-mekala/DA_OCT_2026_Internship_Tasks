from solutions import word_frequency
from solutions import char_frequency
from solutions import non_repeating_char
from solutions import anagram_check
from solutions import repeating_char
from solutions import set_zero__at_end
from solutions import second_highest_distinct_num
from solutions import remove_duplicates
from solutions import missing_num
from solutions import target_sum
from solutions import closest_to_zero
from solutions import common_elements
from solutions import rotate_list
from solutions import maximum_sum_of_consecutive_elements
from solutions import all_pairs_with_target_sum

#****************************************#

print(word_frequency("python is easy and python is powerful"))
print(char_frequency("banana"))
print(non_repeating_char("swiss"))
print(anagram_check("listen","silent"))
print(repeating_char("programming"))
print(set_zero__at_end([0, 3, 0, 1, 2, 0, 4]))
print(second_highest_distinct_num([10, 20, 40, 30, 40, 20]))
print(remove_duplicates([4, 2, 4, 5, 2, 7, 5]))
print(missing_num(6,[1, 2, 4, 5, 6]))
print(target_sum(9,[2, 7, 11, 15]))
print(closest_to_zero([-8, -3, 2, 5, -2]))
print(common_elements([1, 2, 3, 4, 5],[3, 4, 5, 6, 7]))
print(rotate_list(2,[1, 2, 3, 4, 5]))
print(maximum_sum_of_consecutive_elements([4, 7, 2, 9, 5]))
print(all_pairs_with_target_sum([2, 4, 3, 5, 7, 8, 1],9))


