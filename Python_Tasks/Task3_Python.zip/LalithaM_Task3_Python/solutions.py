# Q1. Find the Frequency of Each Word in a Sentence
def word_frequency(sentence):
    words= sentence.split()
    d={}
    for word in words:
        if word not in d:
            d[word]=1
        else:
            d[word] +=1
    return d
########################################
# Q2. Find the Frequency of Each Character in a Word
def char_frequency(word):
    d={}
    for i in word:
        if i not in d:
            d[i]=1
        else:
            d[i] +=1
    return d

###########################################
# Q3. Find the First Non-Repeating Character in a Word
def non_repeating_char(word):
    d={}
    for i in word:
        if i not in d:
            d[i]=1
        else:
            d[i] +=1
    for key in d:
        if d[key]==1:
         return(key)
##################################################
# Q4. Check Whether Two Strings Are Anagrams
def anagram_check(word1,word2):
    s_word1= sorted(word1)
    s_word2= sorted(word2)
    return(s_word1 == s_word2)
    
#########################################
# Q5. Find the First Repeating Character in a String
def repeating_char(word):
    d={}
    for i in word:
        if i not in d:
            d[i]=1
        else:
            d[i] +=1
    for key in d:
        if d[key]>1:
         return(key)

###################################################
#Q6. Move All Zeros to the End of a List
def set_zero__at_end(list):
    l1 = []
    l2 = []
    for i in list:
        if i != 0:
           l1.append(i)
        if i == 0:
            l2.append(i)
    return(l1+l2)

##################################################
# Q7. Find the Second Highest Distinct Number in a List
def second_highest_distinct_num(lt):
    l=list(set(lt))
    n= len(l)
    if n < 2:
        return None
    for i in range(n):
        for j in range(n-1-i):
            if l[j] < l[j+1]:
               l[j],l[j+1] = l[j+1],l[j]
    return l[1]

############################################
# Q8. Remove Duplicates Without Changing the Original Order
def remove_duplicates(lt):
    l=[]
    for i in lt:
        if i not in l:
            l.append(i)
    return l

##############################################
# Q9. Find the Missing Number from 1 to N
def missing_num(N,lt):
    
    for i in range(1,N+1):
        if i not in lt:
            return i
################################################
# Q10. Find Two Numbers Whose Sum Equals a Target
def target_sum(target,lt:list):
    for i in range(len(lt)):
        for j in range(i+1,len(lt)):
            if lt[i]+lt[j] == target:
                 return [lt[i],lt[i+1]]
    return None


#################################################
# Q11. Find the Number Closest to Zero
def closest_to_zero(nums: list[int]):
    closest = nums[0]

    for i in nums:
        if abs(i) < abs(closest):
            closest = i
        elif abs(i) == abs(closest) and i > closest:
            closest = i

    return closest
######################################################
# Q12. Find Common Elements Between Two Lists
def common_elements(lst1,lst2):
    lst=[]
    for i in lst1:
        if i in lst2 and i not in lst:
            lst.append(i)
    return lst

########################################################
#Q13. Rotate a List to the Right by K Positions
def rotate_list(K,lst):
    K = K % len(lst)
    for i in range(K):
        last = lst.pop()
        lst.insert(0,last)
    return lst

######################################################
#Q14. Find the Maximum Sum of Two Consecutive Elements
def maximum_sum_of_consecutive_elements(lst):
    max_sum = lst[0]+lst[1]
    for i in range(len(lst)-1):
        current_sum =lst[i]+lst[i+1]
        if current_sum > max_sum:
            max_sum = current_sum
    return max_sum
        

#################################################
# Q15. Find All Pairs of Numbers Whose Sum Equals a Target
def all_pairs_with_target_sum(lst, target):
    pairs = []

    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            if lst[i] + lst[j] == target:
                pair = sorted([lst[i], lst[j]])

                if pair not in pairs:
                    pairs.append(pair)

    pairs.sort(key=lambda pair: pair[0])
    return pairs


